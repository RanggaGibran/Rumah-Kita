// This is a stub file to ensure importing from './PetInteraction' works
// The actual implementation is in PetInteraction.tsx 
// Note: We don't include the .tsx extension in the import path in JavaScript
export { default } from './PetInteraction.tsx';
